<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pemilih extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('pemilih_m');
    }

    public function index(){
        $data['pemilih'] = $this->pemilih_m->getData();

        $this->load->view('templates/header');
        $this->load->view('pemilih/halamanpemilih', $data);
    }
}