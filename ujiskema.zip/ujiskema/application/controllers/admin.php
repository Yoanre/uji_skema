<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model("admin_m");
    }

    public function index(){
        $data['user'] = $this->admin_m->getData();

        $this->load->view('templates/header');
        $this->load->view('admin/halamanadmin', $data);
    }

    public function tambah(){
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if($this->form_validation->run() == FALSE){
            $this->load->view('templates/header');
            $this->load->view('admin/tambah');
        }else{
            $this->admin_m->tambahAdmin();
            redirect('admin');
        }
    }

    public function edit($id)
    {
        $data['user'] = $this->admin_m->getAdminById($id);
       
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if($this->form_validation->run() == FALSE){
            $this->load->view('templates/header');
            $this->load->view('admin/edit', $data);
        }else{
            $this->admin_m->editAdmin();
            redirect('admin');
        }
    }

    public function hapus($id){
        $this->admin_m->hapusAdmin($id);
        redirect('admin');
    }
}