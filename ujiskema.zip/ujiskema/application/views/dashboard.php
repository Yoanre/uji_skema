<h1>halaman dashboard</h1>
<a href="<?= base_url('loginpemilih') ?>" class="btn btn-danger">login</a>