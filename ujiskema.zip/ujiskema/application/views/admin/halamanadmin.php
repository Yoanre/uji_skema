<h1 class="text-center">Data Admin</h1>
<div class="container">
<a href="<?= base_url('admin/tambah') ?>" class="btn btn-primary">Tambah</a>
<a href="<?= base_url('loginadmin') ?>" class="btn btn-danger">logout</a>
</div>
<div class="carousel d-flex justify-content-center mt-5 ">
    <table class="table table-bordered" style="width: 70%;">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama</th>
                <th scope="col">Email</th>
                <th scope="col">Password</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            <?php foreach($user as $usr) : ?>
            <tr>
                <th scope="row"><?= $no++ ?></th>
                <td><?= $usr['username'] ?></td>
                <td><?= $usr['email'] ?></td>
                <td><?= $usr['password'] ?></td>
                <td><a href="<?= base_url('admin/edit/') ?><?= $usr['id_user'] ?>" class="btn btn-warning">Edit</a>
                <a href="<?= base_url('admin/hapus/') ?><?= $usr['id_user'] ?>" class="btn btn-danger" onclick="return confirm('yakin ingin menghapus <?= $usr['username'] ?> ini?') ">Hapus</a></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>