<h1 class="d-flex justify-content-center mt-5">Tambah Admin</h1>
<div class="tambah d-flex justify-content-center mt-5">
    <div class="card" style="width: 50%;">
        <div class="container my-5">
            <form action="" method="POST">
                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" id="username">
                </div>
                <div class="mb-3">
                    <label class="form-label">E-mail</label>
                    <input type="text" name="email" class="form-control" id="email">
                </div>
                <div class="mb-3">
                    <label class="form-label">password</label>
                    <input type="password" name="password" class="form-control" id="password">
                </div>
                <button href="<?=base_url();?> admin" type="submit" name="tambah" class="btn btn-success">Tambah</button>
                <button type="reset" class="btn btn-danger">Reset</button>
            </form>
        </div>
    </div>
</div>