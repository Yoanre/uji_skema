<h1 class="d-flex justify-content-center mt-5">LOGIN ADMIN</h1>
<div class="container mt-5">
    <div class="login d-flex" style="justify-content: center;">
        <div class="card" style="width: 30%;">
            <div class="container">
                <form class="my-5" method="post" action="<?= base_url('loginadmin/proses') ?>">
                    <div class="form-group mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" name="username" aria-describedby="emailHelp">
                    </div>
                    <div class="form-group mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" class="form-control" name="password">
                    </div>
                    <button type="submit" name="login" class="btn btn-primary">Submit</button>
                    <a href="<?= base_url('loginpemilih') ?>" class="btn btn-outline-secondary btn-sm">Login sebagai pemilih</a>
                </form>
            </div>
        </div>
    </div>
</div>