<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class kandidat_m extends CI_Model {

    public function getId($id){
        return $this->db->get_where('kandidat', ['id_kandidat' => $id])->row_array();
    }
}