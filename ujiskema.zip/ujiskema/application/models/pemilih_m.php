<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pemilih_m extends CI_Model {
    public function login($post){
        $this->db->select('*');
        $this->db->from('pemilih');
        $this->db->where('username', $post['username']);
        $this->db->where('password', sha1($post['password']));
        $query = $this->db->get();
        return $query;
    }
    public function getData(){
        return $this->db->get('pemilih')->result_array();
    }
}